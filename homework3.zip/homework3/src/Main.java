import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.printf("Введите число");
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();

        if(a%2==0){
            System.out.println("число четное");
        } else {
            System.out.println("число не четное");
        }

        System.out.println("Введите день недели");
        String day = in.next();
        switch (day){
            case "понедельник":
            case "вторник":
            case "среда":
            case "четверг":
            case "пятница":
                System.out.println(day+"- рабочий день");
                break;
            case "суббота":
            case "воскременье":
                System.out.println(day + "- выхоной день");
                break;
            default:
                System.out.println("не знаю такой день недели");
        }
    }
}