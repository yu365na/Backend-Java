public class Main {
    public static void main(String[] args){
        Instrument myDrum = new Drum(30);
        myDrum.play();
        Guitar myGuitar = new Guitar(5);
        myGuitar.play();
        Trumpet myTrumpet = new Trumpet(15.5);
        myTrumpet.play();
    }
}