public interface Instrument {
    String KEY = "до мажор";
    void play();

}
