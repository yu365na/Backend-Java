public class Guitar implements Instrument{
int stringCount;
Guitar(int stringCount){
    this.stringCount=stringCount;
}
    @Override
    public void play() {
        System.out.printf("Играет гитара, %d колличество струн\n",stringCount);
        }

}
