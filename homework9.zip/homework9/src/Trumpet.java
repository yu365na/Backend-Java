public class Trumpet implements Instrument{

double d;

    public Trumpet(double d) {
        this.d = d;
    }

    @Override
    public void play() {
        System.out.printf("Играет труба, диаметр%f\n",d);
    }
}
