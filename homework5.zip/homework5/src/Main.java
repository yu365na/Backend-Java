import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Введите сумму в рублях");
        int rur = in.nextInt();
        System.out.println("Введите курс к евро");
        double course = in.nextDouble();
        double res = toEURO(rur, course);
        System.out.println(res);
        System.out.println("Введите сумму в рублях");
        rur = in.nextInt();
        System.out.println("Введите курс к евро");
        course = in.nextDouble();
        res = toEURO(rur, course);
        System.out.println(res);

        System.out.println("Введите число");
        int num = in.nextInt();
        System.out.println("Введите степень");
        int st= in.nextInt();
        System.out.println(getPow(num,st));

    }
       static double toEURO(int rur, double course){
        return rur/course;
       }
       static  int getPow(int num, int st ){
        int res=1;
        for( int i= 0; i<st; i++){
            res*=num;

        }
        return res;
       }
}