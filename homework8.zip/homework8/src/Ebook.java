public class Ebook extends Edition {
    private String url;
    private String annotation;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAnnotation() {
        return annotation;
    }

    public void setAnnotation(String annotation) {
        this.annotation = annotation;
    }

    @Override
    public void printInfo() {
        System.out.println(getName()+" "+getSurname()+" "+getUrl()+" "+getAnnotation());

    }
}
