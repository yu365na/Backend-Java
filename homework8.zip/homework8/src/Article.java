public class Article extends Edition{
    private String journalName;
    private int id;
    private int year;

    public String getJournalName() {
        return journalName;
    }

    public void setJournalName(String journalName) {
        this.journalName = journalName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public void printInfo() {
        System.out.println(getName()+ " "+ getSurname()+" "+ getJournalName()+ getId()+" "+getYear());
    }
}
