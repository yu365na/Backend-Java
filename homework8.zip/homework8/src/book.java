public class book extends Edition{
    private String publisher;
    private int year;


    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public void printInfo() {
        System.out.println(getName()+" "+getSurname()+ " "+ getPublisher()+ " "+getYear());
    }
}
