public class Main {
    public  static void  main(String[] args) {
      book mybook = new book();
      mybook.setName("Название");
      mybook.setSurname("Фамилия автора");
      mybook.setPublisher("Издательство");
      mybook.setYear(2008);
      mybook.printInfo();
      Article myArticle = new Article();
      myArticle.setName("Название статьи");
      myArticle.setSurname("Фамилия автора статьи");
      myArticle.setJournalName("Название журнала");
      myArticle.setYear(2013);
      myArticle.setId(1234);
      myArticle.printInfo();
      Ebook myEbook = new Ebook();
      myEbook.setName("Название элекронного ресурса");
      myEbook.setSurname("фамилия автора");
      myEbook.setAnnotation("Аннотация");
      myEbook.setUrl("https://hggbbbh");
      myEbook.printInfo();


    }
}