public class Tiles {
    String brand;
    double size_h;
    double size_w;
int price;

Tiles(String brand,double size_h, double size_w, int price){
    this.brand=brand;
    this.size_h= size_h;
    this.size_w=size_w;
    this.price=price;
}
Tiles(String brand, int price){
    this(brand, 12, 12,price);
}
Tiles(String brand, double size_h, int price){
    this(brand,size_h,size_h, price);
}
void getData(){
    System.out.println(brand+"  "+size_h+"   "+size_w+"  "+price);
}
}
