public class Main {
    public static void main(String[] args){
        System.out.println("Hello world!");
        Tiles fTiles = new Tiles("myBrand", 12, 12, 120);
        fTiles.getData();
        Tiles sTiles = new Tiles("myBrand",130);
        sTiles.getData();
         Tiles lTiles = new Tiles("someBrand",56,1222);
         lTiles.getData();

    }
}