public class Main {
    public static void main(String[] args){
        System.out.println("Hello world");
        Car car = new Car();
        car.setMark("Audi");
        car.setColor("Black");
        car.setId("PP123P321");
        car.setOdo(12345678);
        car.setSeats(9);
        car.setGas(68);
        car.printInfo();


    }
}
class Car {
    private String mark;
    private String color;
    private int odo;
    private String id;
    private double gas;
    private int seats;

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getOdo() {
        return odo;
    }

    public void setOdo(int odo) {

        this.odo = odo/1000;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getGas() {
        return gas;
    }

    public void setGas(double gas) {
        this.gas = gas;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        if (seats > 8) {
            this.seats = 1;
            System.out.println("Мaксимум 8 мест");
        } else {
            this.seats = seats;
        }
    }
    public void printInfo(){
        System.out.printf("%s, цвет %s, номер %s, мест %d, осталось %f л. бензина, пробег %fкм", getMark(), getColor(), getId(),getSeats(), getGas(), getOdo());
    }
}