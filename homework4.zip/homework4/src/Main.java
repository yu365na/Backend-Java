import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите целое число");
        Scanner in = new Scanner(System.in);
        int[] array = new int[in.nextInt()];
        for (int i=0; i<array.length;i++){
            System.out.println("Введите значение массива");
            array[i]= in.nextInt();
        }
        Arrays.sort(array);
        for (int a:array){
            System.out.println(a);
        }

        System.out.println("Введите целое число");
        int x = in.nextInt();

        System.out.println("Введите целое число");
        int y = in.nextInt();

        int[][] bigArray = new int[x][y];
        for(int i = 0; i < bigArray.length; i++ ){
           for(int j = 0; j<bigArray[0].length; j++){
               bigArray[i][j]=in.nextInt();
           }
        }
        int result = 0;
        for(int[] arr:bigArray){
            for (int a: arr) {
                result+=a;
            }
        }
        System.out.println(result);
    }
}